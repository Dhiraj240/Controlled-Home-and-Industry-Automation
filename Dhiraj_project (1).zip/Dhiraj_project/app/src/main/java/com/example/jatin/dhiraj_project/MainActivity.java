package com.example.jatin.dhiraj_project;

import android.content.DialogInterface;
import android.content.Intent;
import android.preference.DialogPreference;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        final AlertDialog alertDialog = new AlertDialog.Builder(MainActivity.this).create();
        alertDialog.setTitle("Alert");
        alertDialog.setMessage("The reading level is high");
        alertDialog.setButton(AlertDialog.BUTTON_POSITIVE, "Send Email",
                new DialogInterface.OnClickListener() {

                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Intent email = new Intent(Intent.ACTION_SEND);
                        email.putExtra(Intent.EXTRA_EMAIL,new String[]{"hhh"});
                        email.putExtra(Intent.EXTRA_SUBJECT, "Hello World");
                        email.putExtra(Intent.EXTRA_TEXT, "Hey");
                        email.setType("message/rfc822");

                        startActivity(Intent.createChooser(email, "Choose an Email client :"));
                    }
                }

        );
       alertDialog.setButton(AlertDialog.BUTTON_NEGATIVE,"No Thanks",
               new DialogInterface.OnClickListener(){

                   @Override
                   public void onClick(DialogInterface dialog, int which) {
                       dialog.dismiss();
                   }
               }
               );

        alertDialog.show();
    }
}
